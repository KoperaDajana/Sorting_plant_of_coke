// MODEL: próbki, które są pobierane z wagonów
const mongoose = require('mongoose');

// powie o tym jak powinna wyglądać próbka
const sampleSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    sample_weight: {type: Number, default: 1},
    mineral_content: {type: String, required: true},           // zawartość mineralna próbki
    granulation_min: {type: Number, default: 0.0001},      // wyniki z badań dotyczących granulacji
    granulation_max: {type: Number, default: 10},
    high_of_grain: {type: Number, default: 1},
    width_of_grain: {type: Number, default: 1},
    carriage: {type: mongoose.Schema.Types.ObjectId, ref: 'Carriage', required: true}
});

module.exports = mongoose.model('Sample', sampleSchema);