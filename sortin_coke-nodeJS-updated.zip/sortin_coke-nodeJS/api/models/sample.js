// MODEL: próbki, które są pobierane z wagonów
const mongoose = require('mongoose');

// powie o tym jak powinna wyglądać próbka
const sampleSchema = mongoose.Schema({
    //_id: mongoose.Schema.Types.ObjectId,
    sample_weight: {type: Number, default: 1},
    date_sample: {type: Number, default: 10011001},
    carriage: {type: mongoose.Schema.Types.ObjectId, ref: 'Carriage', required: true},
    // pozostałe niewymagane ze względu na to, że uzupełniane różnie w czasie
    composition: {type: mongoose.Schema.Types.ObjectId, ref: 'Composition', required: false}, //skład mineralny
    granulation: {type: mongoose.Schema.Types.ObjectId, ref: 'Granulation', required: false}, //odpowiada za info o ziarnie
    research: {type: mongoose.Schema.Types.ObjectId, ref: 'Research', required: false}
});

module.exports = mongoose.model('Sample', sampleSchema);