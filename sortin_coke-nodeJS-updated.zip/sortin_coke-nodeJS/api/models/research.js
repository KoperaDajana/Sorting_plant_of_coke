// MODEL: badania
const mongoose = require('mongoose');

// powie o tym jak powinna wyglądać informacja o badaniu
const researchSchema = mongoose.Schema({
    //_id: mongoose.Schema.Types.ObjectId,
    research_type: {type: String, required: true},
    energy: {type: Number, default: 666}
});

module.exports = mongoose.model('Research', researchSchema);