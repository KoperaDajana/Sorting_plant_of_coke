// BADANIA

const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");
const checkAuth = require('../middleware/check-auth');
const Research = require('../models/research');


// GET z handlerem
router.get("/", (req, res, next) => {
    Research.find()
        .select("research_type energy _id")
        .exec()
        .then(docs => {
            res.status(200).json({
                count: docs.length,
                researches: docs.map(doc => {
                    return {
                        _id: doc._id,
                        research_type: doc.research_type,
                        energy: doc.energy
                    };
                })
            });
        })
        .catch(err => {
            res.status(500).json({
                error: err
            });
        });
});


// POST - dodawanie badań
router.post("/", checkAuth, (req, res, next) => {
    const research = new Research({
        research_type: req.body.research_type,
        energy: req.body.energy
    });
    research.save()
        .then(result => {
            console.log(result);
            res.status(201).json({
                message: "Research stored",
                createdResearch: {
                    _id: result._id,
                    research_type: result.research_type,
                    energy: result.energy
                }
            });
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        });
});

// GET SZCZEGÓLNE intormacje o konkretnym badaniu
router.get('/:researchId', (req, res, next) => {
    const id = req.params.researchId;
    Research.findById(id)
        .select("research_type energy _id")
        .exec()
        .then(doc => {
            console.log("From DB", doc);
            if (doc) {
                res.status(200).json({
                    research: doc
                });
            } else {
                res.status(404).json({message: 'Valid entry'});
            }
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({error: err});
        });
});


// PATCH - aktualizacje
router.patch("/:researchId", checkAuth, (req, res, next) => {
    const id = req.params.researchId;
    const updateOperations = {};             // pusty obiekt JS
    for (const operations of req.body) {     // by była możliwość uzupełniania po pojedynczych wartościach elementu
        updateOperations[operations.propertyName] = operations.value;
    }
    Research.update({_id: id}, {$set: updateOperations})
        .exec()
        .then(result => {
            res.status(200).json({
                message: 'Research updated'
            });
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        })
});


// DELETE (do autoryzacji - checkAuth,)
router.delete("/:researchId", checkAuth, (req, res, next) => {
    const id = req.params.researchId;
    Research.remove({_id: id})
        .exec()
        .then(result => {
            res.status(200).json({
                message: 'Research deleted'
            });
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        });
});

module.exports = router;